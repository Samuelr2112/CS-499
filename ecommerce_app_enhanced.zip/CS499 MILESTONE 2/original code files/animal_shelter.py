from pymongo import \
    MongoClient  # Importing the MongoClient from the pymongo library to interact with MongoDB.


# Define the AnimalShelter class to encapsulate CRUD operations for MongoDB.
class AnimalShelter:
    # Initialize the connection to the MongoDB database and collection.
    def __init__(self, db='AAC', collection='animals'):
        try:
            # Establish connection to MongoDB using the local host and default port.
            self.client = MongoClient('mongodb://localhost:27017/')
            # Connect to the specified database and collection.
            self.database = self.client[db]
            self.collection = self.database[collection]
        except Exception as e:
            # Handle any connection errors and provide feedback.
            print(f"Failed to connect to MongoDB: {e}")

    # Method to create a new document in the MongoDB collection.
    def create(self, data):
        # Check if the provided data is not empty.
        if data:
            try:
                # Insert the document into the MongoDB collection.
                self.collection.insert_one(data)
                print("Document inserted successfully.")  # Provide feedback on successful insertion.
                return True  # Return True to indicate success.
            except Exception as e:
                # Handle errors during insertion and provide feedback.
                print(f"An error occurred during insertion: {e}")
                return False  # Return False to indicate failure.
        else:
            # Inform the user that no data was provided for insertion.
            print("No data provided to insert.")
            return False  # Return False since no operation was performed.

    # Method to read documents from the MongoDB collection based on a query.
    def read(self, query):
        try:
            # Perform a query on the collection and convert the results to a list.
            results = list(self.collection.find(query))
            # Return the results if any documents are found; otherwise, return an empty list.
            return results if results else []
        except Exception as e:
            # Handle errors during the read operation and provide feedback.
            print(f"An error occurred during reading: {e}")
            return []  # Return an empty list if an error occurs.

    # Method to update a document in the MongoDB collection based on a query.
    def update(self, query, new_values):
        try:
            # Update a single document that matches the query with the provided new values.
            result = self.collection.update_one(query, {'$set': new_values})
            # Provide feedback on how many documents were updated.
            print(f"{result.modified_count} document(s) updated.")
            return result.modified_count  # Return the count of modified documents.
        except Exception as e:
            # Handle errors during the update operation and provide feedback.
            print(f"An error occurred during updating: {e}")
            return 0  # Return 0 to indicate no documents were updated.

    # Method to delete a document from the MongoDB collection based on a query.
    def delete(self, query):
        try:
            # Delete a single document that matches the query.
            result = self.collection.delete_one(query)
            # Provide feedback on how many documents were deleted.
            print(f"{result.deleted_count} document(s) deleted.")
            return result.deleted_count  # Return the count of deleted documents.
        except Exception as e:
            # Handle errors during the deletion operation and provide feedback.
            print(f"An error occurred during deletion: {e}")
            return 0  # Return 0 to indicate no documents were deleted.
