import logging  # Importing logging to handle error and info messages

from pymongo import \
    MongoClient  # Importing MongoClient to interact with MongoDB

# Configure logging to capture error messages and information
logging.basicConfig(
    filename='animal_shelter.log',  # Log file name
    level=logging.INFO,  # Logging level set to INFO
    format='%(asctime)s - %(levelname)s - %(message)s'  # Log message format
)

class AnimalShelter:
    """
    A class to encapsulate CRUD operations for MongoDB.
    """

    def __init__(self, db='AAC', collection='animals'):
        """
        Initialize the connection to the MongoDB database and collection.
        """
        try:
            # Establish connection to MongoDB using localhost and default port.
            self.client = MongoClient('mongodb://localhost:27017/')
            # Connect to the specified database and collection.
            self.database = self.client[db]
            self.collection = self.database[collection]
            logging.info("Connected to MongoDB successfully.")
        except Exception as e:
            logging.error(f"Failed to connect to MongoDB: {e}")
            raise Exception("Database connection failed.")

    def create(self, data):
        """
        Inserts a new document into the MongoDB collection.

        Args:
            data (dict): A dictionary containing the document to be inserted.

        Returns:
            bool: True if insertion was successful, False otherwise.
        """
        if data:
            try:
                self.collection.insert_one(data)
                logging.info("Document inserted successfully.")
                return True
            except Exception as e:
                logging.error(f"An error occurred during insertion: {e}")
                return False
        else:
            logging.warning("No data provided for insertion.")
            return False

    def read(self, query):
        """
        Retrieves documents from the MongoDB collection based on a query.

        Args:
            query (dict): A dictionary specifying the query criteria.

        Returns:
            list: A list of retrieved documents, or an empty list if none found.
        """
        try:
            results = list(self.collection.find(query))
            logging.info(f"Read operation successful. Retrieved {len(results)} document(s).")
            return results if results else []
        except Exception as e:
            logging.error(f"An error occurred during reading: {e}")
            return []

    def update(self, query, new_values):
        """
        Updates a document in the MongoDB collection based on a query.

        Args:
            query (dict): The query criteria to find the document.
            new_values (dict): The new values to update in the document.

        Returns:
            int: Number of documents modified.
        """
        try:
            result = self.collection.update_one(query, {'$set': new_values})
            logging.info(f"{result.modified_count} document(s) updated.")
            return result.modified_count
        except Exception as e:
            logging.error(f"An error occurred during updating: {e}")
            return 0

    def delete(self, query):
        """
        Deletes a document from the MongoDB collection based on a query.

        Args:
            query (dict): The query criteria to find the document to delete.

        Returns:
            int: Number of documents deleted.
        """
        try:
            result = self.collection.delete_one(query)
            logging.info(f"{result.deleted_count} document(s) deleted.")
            return result.deleted_count
        except Exception as e:
            logging.error(f"An error occurred during deletion: {e}")
            return 0
