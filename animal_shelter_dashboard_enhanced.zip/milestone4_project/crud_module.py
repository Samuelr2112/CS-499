import logging

from pymongo import MongoClient, errors

# Configure logging to handle error reporting and debugging
# (This logging configuration is new to provide detailed execution information)
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class CRUD:
    def __init__(self, username, password, database):
        """
        Initialize the CRUD class with MongoDB client connection.
        :param username: MongoDB username
        :param password: MongoDB password
        :param database: Database name to connect to
        """
        # New: Added connection timeout and validation using the 'ping' command to ensure the connection is successful
        uri = f"mongodb://{username}:{password}@nv-desktop-services.apporto.com:33507/{database}?authSource=admin"
        try:
            self.client = MongoClient(uri, serverSelectionTimeoutMS=5000)  # New timeout setting
            self.db = self.client[database]
            self.client.admin.command('ping')  # Test connection to ensure the database is reachable
            logging.info("Connected to MongoDB successfully.")
        except errors.ConnectionFailure as e:
            logging.error("Connection failed: %s", e)
            raise

    def create_document(self, collection_name, document):
        """
        Insert a document into the specified collection.
        :param collection_name: Name of the collection
        :param document: Dictionary representing the document to insert
        """
        # Enhanced: Added error handling with logging to track document insertion issues
        try:
            collection = self.db[collection_name]
            result = collection.insert_one(document)
            logging.info("Document inserted with ID: %s", result.inserted_id)
            return result.inserted_id
        except errors.PyMongoError as e:
            logging.error("Error inserting document: %s", e)
            return None

    def read_document(self, collection_name, query):
        """
        Retrieve documents matching a query from the specified collection.
        :param collection_name: Name of the collection
        :param query: Dictionary representing the query criteria
        """
        # Enhanced: Improved error handling and logging for read operations
        try:
            collection = self.db[collection_name]
            documents = collection.find(query)
            return list(documents)
        except errors.PyMongoError as e:
            logging.error("Error reading documents: %s", e)
            return []

    def update_document(self, collection_name, query, update_values):
        """
        Update documents matching a query in the specified collection.
        :param collection_name: Name of the collection
        :param query: Dictionary representing the query criteria
        :param update_values: Dictionary representing the update operations
        """
        # Enhanced: Added logging to provide insight into the number of documents updated
        try:
            collection = self.db[collection_name]
            result = collection.update_many(query, {'$set': update_values})
            logging.info("Matched %d documents, modified %d documents", result.matched_count, result.modified_count)
            return result.modified_count
        except errors.PyMongoError as e:
            logging.error("Error updating documents: %s", e)
            return 0

    def delete_document(self, collection_name, query):
        """
        Delete documents matching a query from the specified collection.
        :param collection_name: Name of the collection
        :param query: Dictionary representing the query criteria
        """
        # Enhanced: Added logging to track the number of documents deleted
        try:
            collection = self.db[collection_name]
            result = collection.delete_many(query)
            logging.info("Deleted %d documents", result.deleted_count)
            return result.deleted_count
        except errors.PyMongoError as e:
            logging.error("Error deleting documents: %s", e)
            return 0

    def close_connection(self):
        """
        Close the MongoDB client connection.
        """
        # Enhanced: Added logging to confirm the connection is closed
        self.client.close()
        logging.info("MongoDB connection closed.")
